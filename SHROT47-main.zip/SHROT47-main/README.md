# SHROT47: Единая система управления контекстом клиента и автозапчастей

Рабочая база проекта для автономной разработки. Вся проектная документация синхронизирована, архитектурные противоречия устранены, границы ответственности компонентов строго зафиксированы.

---

## 🏛️ Каноническая архитектура и границы ответственности

Целевой сквозной пайплайн обработки запросов:

```
WhatsApp Клиент
      │
      ▼
  SendPulse (Транспорт сообщений)
      │
      ▼ (Webhook)
     n8n (Единый оркестратор событий)
      │   ├─ 1. Webhook Intake (единственная точка входа)
      │   ├─ 2. Dedupe (отсечение дублей по external_message_id)
      │   ├─ 3. Debounce (склейка серии быстрых сообщений клиента)
      │   ├─ 4. Normalization (E.164 телефоны, структура payload)
      │   ├─ 5. Context Read (чтение истории из Supabase)
      │   ├─ 6. AI Agent Call (вызов LLM с контекстом)
      │   ├─ 7. State Write (запись сообщений, заявок, деталей)
      │   └─ 8. Outbound / Handoff (ответ через SendPulse или эскалация)
      │
      ├───► Supabase (Hard State / SSOT — 8 канонических таблиц)
      │
      ├───► AI Agent (Семантический анализ, intent, извлечение параметров)
      │
      ▼
  SendPulse → WhatsApp Клиент
```

### Матрица владения функциями (Responsibility Matrix)

| Функция / Зона ответственности | Единственный владелец (Owner) | Обоснование и правила |
| :--- | :--- | :--- |
| **Webhook Intake** | **`n8n`** | Прямой приём вебхуков от SendPulse. Без промежуточных прокси. |
| **Dedupe** | **`n8n`** | Проверка `external_message_id` в таблице `messages` перед обработкой. |
| **Debounce** | **`n8n`** | Буферизация быстрых сообщений (5–15 сек) в единый блок перед вызовом AI. |
| **Normalization** | **`n8n`** | Приведение телефонов к E.164 и очистка текста реплики. |
| **Database Writes** | **`n8n` → `Supabase`** | n8n оркестрирует чтение и запись в Supabase. Единый источник записи. |
| **AI Calls** | **`AI Agent` (вызов из `n8n`)** | LLM возвращает строго структурированный JSON, в БД напрямую не пишет. |
| **Outbound / Handoff** | **`n8n` → `SendPulse`** | n8n отправляет ответ в WhatsApp либо переводит диалог в `human_handoff`. |

> [!IMPORTANT]
> **Принцип:** *ONE PURPOSE → ONE COMPONENT → ONE SOURCE OF TRUTH*.  
> Никакого дублирования обязанностей между n8n и бэкендом. Внедрение FastAPI, Celery, Redis и Whisper **заморожено** до тех пор, пока их необходимость не будет строго доказана в рамках развития проекта.

---

## 📊 Матрица состояния компонентов репозитория

| Компонент / Артефакт | Категория | Статус в репозитории | Описание / Путь |
| :--- | :--- | :--- | :--- |
| **Правила разработки агентов** | `CONFIRMED` | ✅ Синхронизировано | [`AGENTS.md`](AGENTS.md) — мастер-инструкции, 28 принципов, границы ответственности |
| **Каноническая архитектура** | `CONFIRMED` | ✅ Синхронизировано | Единая цепочка: SendPulse → n8n → AI Agent → Supabase |
| **Каноническая спецификация схемы** | `CONFIRMED` | ✅ Синхронизировано | [`migrations/README.md`](migrations/README.md) — строго 8 канонических таблиц |
| **Политика безопасности (.gitignore)** | `CONFIRMED` | ✅ Присутствует | [`.gitignore`](.gitignore) — фильтрация секретов, ключей, токенов, кэша |
| **Шаблон конфигурации** | `CONFIRMED` | ✅ Присутствует | [`.env.example`](.env.example) — безопасный образец переменных |
| **Стратегия веток и Git Workflow** | `CONFIRMED` | ✅ Присутствует | [`BRANCH_STRATEGY.md`](BRANCH_STRATEGY.md), [`CONTRIBUTING.md`](CONTRIBUTING.md) |
| **CI/CD Pipeline с валидацией** | `CONFIRMED` | ✅ Активен | [`.github/workflows/ci.yml`](.github/workflows/ci.yml) |
| **Канонический бэклог задач** | `CONFIRMED` | ✅ Синхронизировано | [`docs/GITHUB_ISSUES.md`](docs/GITHUB_ISSUES.md) — актуальные драфты задач |
| **Аудит секретов в Git history** | `CONFIRMED` | ✅ Проверен | 0 утечек секретов во всех коммитах истории |
| **Read-Only Runtime Audit Package** | `CONFIRMED` | ✅ Реализован | [`docs/RUNTIME_AUDIT_ACCESS.md`](docs/RUNTIME_AUDIT_ACCESS.md), `scripts/audit/`, `.env.audit.example` |
| **MCP Hub координации агентов** | `NOT VERIFIED`| ⚠️ Эксперимент | Ветка `master` (TypeScript / SQLite WASM), не влита в `main` |
| **Внешние production-окружения** | `NOT VERIFIED`| ⚠️ Вне Git | Инстансы Supabase, SendPulse, Asterisk |
| **Каноническая миграция Supabase** | `MISSING` | ❌ Ожидает реализации | `migrations/supabase/001_canonical_schema.sql` (8 таблиц) |
| **n8n Workflows (манифесты)** | `MISSING` | ❌ Ожидает реализации | `workflows/n8n/whatsapp_orchestrator.json` |
| **AI Agent Prompt & Contract** | `MISSING` | ❌ Ожидает реализации | `docs/AI_AGENT_CONTRACT.md` (JSON Schema ответов) |
| **Набор тестов (smoke scenarios)** | `MISSING` | ❌ Ожидает реализации | 10 smoke-сценариев из AGENTS.md |
| **FastAPI / Celery / Redis / Whisper** | `HISTORICAL`| ⏸️ Заморожено | Избыточная инфраструктура, не входит в канонический MVP |
| **Устаревшие плоские таблицы БД** | `HISTORICAL`| 📜 Архив | `calls`, `call_facts`, `whatsapp_messages`, `outbox`, `identities_review` |

---

## 1. 🟢 CONFIRMED (Подтверждено и зафиксировано)

1. **[`AGENTS.md`](AGENTS.md)** — канонический свод правил и архитектурных принципов:
   - 28 базовых принципов разработки и верификации;
   - Запрет прямых правок в `main`, обязательность PR и CI;
   - Единая граница ответственности между SendPulse, n8n, AI Agent и Supabase;
   - Запрет фиктивного кода и пустых заглушек.
2. **Каноническая схема данных (8 таблиц в Supabase)**:
   - `customers` — профили клиентов;
   - `identities` — канальные контакты (с валидацией E.164 и статусом `needs_review`);
   - `conversations` — сессии диалогов и активное авто в контексте;
   - `messages` — сквозная история сообщений с `external_message_id` (для dedupe) и delivery_status;
   - `requests` — заявки на запчасти;
   - `request_parts` — детали в рамках заявки (множественные детали в одном диалоге);
   - `price_results` — результаты оценки цен и наличия (склад, история, рынок);
   - `audit_log` — журнал аудита изменений.
3. **Безопасность**:
   - Строгий [`.gitignore`](.gitignore) и проверенный [`.env.example`](.env.example);
   - Автоматический security-сканер в CI;
   - 0 секретов в истории Git.
4. **Контракты и бэклог**:
   - [`docs/GITHUB_ISSUES.md`](docs/GITHUB_ISSUES.md) синхронизирован с канонической схемой.

---

## 2. 🟡 NOT VERIFIED (Не верифицировано / Экспериментальные ветки)

1. **Ветка `master` (MCP Hub)**: прототип координатора агентов на TypeScript (`shrot47-mcp-hub`). В `main` не слит, в каноническую цепочку не включён.
2. **Внешние аккаунты и ключи**: боевые аккаунты Supabase, SendPulse и телефонии находятся вне репозитория и на данном этапе не переключаются.

---

## 3. 🔴 MISSING (Отсутствует — подлежит последовательной разработке)

1. **Каноническая SQL-миграция Supabase**:
   - Создание файла `migrations/supabase/001_canonical_schema.sql` на основе спецификации из 8 таблиц.
2. **n8n Workflow для WhatsApp**:
   - Экспорт в `workflows/n8n/whatsapp_orchestrator.json` сценария приёма, dedupe, debounce, чтения/записи Supabase и отправки SendPulse.
3. **AI Agent Contract & Prompts**:
   - Документирование системного промпта и JSON-схемы валидации ответов в `docs/AI_AGENT_CONTRACT.md`.
4. **Автоматизированные тесты smoke-сценариев**:
   - Проверка 10 обязательных сценариев из `AGENTS.md`.

---

## 4. 📜 HISTORICAL (Исторический контекст и замороженные гипотезы)

1. **Замороженные компоненты:**
   - FastAPI, Celery воркеры, Redis и транскрипция Whisper признаны не верифицированными для текущего контура и заморожены во избежание дублирования с n8n.
2. **Устаревшие таблицы БД:**
   - Плоские сущности `calls`, `call_facts`, `whatsapp_messages`, `outbox` и `identities_review` из ранних черновиков признаны историческими и полностью заменены реляционной моделью из 8 таблиц.
3. **`Shrot47-polnaya-svodka.md`:**
   - Справочный исторический документ. Не является источником действующих требований.
