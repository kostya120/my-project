# Database Migrations (Supabase / PostgreSQL)

**Статус реализации:** `MISSING` (Ожидает реализации единой миграции)

## 🏛️ Единая каноническая схема данных (8 таблиц)

Supabase является единственным источником истины (**Hard State / Single Source of Truth**). Все противоречия между ранними версиями разрешены в пользу единой доменной модели:

1. **`customers`** — профили клиентов
   - `id` (UUID PK), `first_name`, `last_name`, `primary_phone` (E.164), `status`, `notes`, `created_at`, `updated_at`.
2. **`identities`** — привязка каналов и идентификаторов к клиенту
   - `id` (UUID PK), `customer_id` (FK `customers.id`), `channel` (`whatsapp`, `phone`, `telegram`), `raw_identifier`, `normalized_phone_e164`, `status` (`verified`, `needs_review`), `notes`, `created_at`, `updated_at`.
   - *Примечание:* заменяет отдельную таблицу `identities_review` — сомнительные номера помечаются статусом `needs_review`.
3. **`conversations`** — сессии диалогов
   - `id` (UUID PK), `customer_id` (FK `customers.id`), `channel` (`whatsapp`, `phone`), `status` (`active`, `human_handoff`, `closed`), `active_vehicle` (JSONB), `created_at`, `updated_at`.
4. **`messages`** — сквозная история сообщений всех каналов
   - `id` (UUID PK), `conversation_id` (FK `conversations.id`), `customer_id` (FK `customers.id`), `direction` (`inbound`, `outbound`), `channel` (`whatsapp`, `call_transcript`, `system`), `external_message_id` (VARCHAR UNIQUE — для идемпотентности и dedupe), `content`, `raw_payload` (JSONB), `delivery_status` (`pending`, `sent`, `delivered`, `read`, `failed`), `created_at`.
   - *Примечание:* объединяет разрозненные канальные таблицы и отслеживает статусы доставки, исключая необходимость в дублирующей таблице `outbox`.
5. **`requests`** — заявки на подбор автозапчастей
   - `id` (UUID PK), `customer_id` (FK `customers.id`), `conversation_id` (FK `conversations.id`), `vehicle_brand`, `vehicle_model`, `vehicle_year`, `vehicle_engine`, `vehicle_transmission`, `vin`, `raw_query`, `status` (`open`, `in_progress`, `quoted`, `closed`, `cancelled`), `created_at`, `updated_at`.
6. **`request_parts`** — конкретные запрашиваемые детали в рамках заявки
   - `id` (UUID PK), `request_id` (FK `requests.id` ON DELETE CASCADE), `part_name`, `part_oem`, `condition_preference` (`used`, `new`, `any`), `status` (`pending`, `pricing_in_progress`, `found`, `not_available`), `notes`, `created_at`, `updated_at`.
   - *Примечание:* заменяет устаревшую плоскую структуру `call_facts` и обеспечивает полноценную поддержку множественных деталей в одном запросе (например, "мотор и коробка на гольф 4").
7. **`price_results`** — результаты оценки цен и наличия
   - `id` (UUID PK), `request_part_id` (FK `request_parts.id`), `source_type` (`internal_stock`, `historical_sale`, `market`), `price`, `currency` (KZT), `in_stock`, `supplier_or_source`, `notes`, `search_query` (JSONB), `created_at`.
8. **`audit_log`** — журнал аудита и трассировки изменений
   - `id` (UUID PK), `entity_name`, `entity_id`, `action` (`INSERT`, `UPDATE`, `DELETE`, `HANDOFF`), `changed_by`, `payload` (JSONB), `created_at`.

---

## ⚠️ Резолюция архитектурных противоречий
- **Устаревшие сущности исключены:** плоские таблицы `calls`, `call_facts`, `whatsapp_messages`, `identities_review` и `outbox` признаны историческими и заменены единой реляционной моделью из 8 таблиц выше.
- **SQL-код миграций:** не создавать SQL до фиксации архитектурного консенсуса в проектной документации. Первая каноническая миграция будет оформлена как `migrations/supabase/001_canonical_schema.sql` в рамках отдельной задачи.
