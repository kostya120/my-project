#!/usr/bin/env python3
"""
SHROT47 Repository Contract & Architecture Integrity Verification Script.

Enforces:
1. Architectural synchronization across AGENTS.md, README.md, migrations/README.md, docs/GITHUB_ISSUES.md.
2. Canonical 8-table Supabase schema consistency (no obsolete tables allowed).
3. Anti-Silent-Success enforcement:
   - If SQL migrations exist in migrations/supabase, they must follow naming and contain required tables.
   - If Python code exists in backend/, backend/tests/ is mandatory and cannot be skipped.
   - If workflows exist in workflows/, they must be valid JSON and free of secrets.
"""

import os
import sys
import re
import json
import glob

CANONICAL_TABLES = [
    "customers",
    "identities",
    "conversations",
    "messages",
    "requests",
    "request_parts",
    "price_results",
    "audit_log",
]

OBSOLETE_TABLES = [
    "call_facts",
    "whatsapp_messages",
    "identities_review",
]

DOC_FILES = [
    "AGENTS.md",
    "README.md",
    "migrations/README.md",
    "docs/GITHUB_ISSUES.md",
]


def check_docs_schema_consistency():
    print("=== [1] Verifying Documentation Schema Consistency ===")
    errors = []
    for doc in DOC_FILES:
        if not os.path.isfile(doc):
            errors.append(f"Missing required documentation file: {doc}")
            continue

        with open(doc, "r", encoding="utf-8") as f:
            content = f.read()

        # Verify all 8 canonical tables are documented in each key doc
        for table in CANONICAL_TABLES:
            if table not in content:
                errors.append(f"Document '{doc}' is missing mention of canonical table '{table}'")

        # Verify obsolete tables are not documented as active requirements
        for obs in OBSOLETE_TABLES:
            # Match active table listing like `obs` (not in historical context)
            # Allow mention if explicitly referred as obsolete/historical/заменена
            matches = re.findall(rf"`{obs}`", content)
            if matches:
                # Check if it is clearly labeled as historical or obsolete in the text
                lower_content = content.lower()
                if "historical" not in lower_content and "устаревш" not in lower_content and "архив" not in lower_content:
                    errors.append(f"Document '{doc}' mentions obsolete table '{obs}' without marking it as historical/obsolete!")

    if errors:
        for err in errors:
            print(f"❌ {err}")
        return False

    print(f"✅ All {len(DOC_FILES)} documentation files are consistent and reference all {len(CANONICAL_TABLES)} canonical tables.")
    return True


def check_migration_contract():
    print("\n=== [2] Verifying Database Migration Contract ===")
    migrations_dir = "migrations/supabase"
    if not os.path.isdir(migrations_dir):
        print("ℹ️ migrations/supabase directory not present yet (Status: MISSING). Contract satisfied.")
        return True

    sql_files = glob.glob(os.path.join(migrations_dir, "*.sql"))
    if not sql_files:
        print("ℹ️ No SQL migrations present yet in migrations/supabase. Contract satisfied.")
        return True

    errors = []
    print(f"Found {len(sql_files)} SQL migration(s). Validating...")
    for sql_file in sorted(sql_files):
        filename = os.path.basename(sql_file)
        if not re.match(r"^\d{3}_[a-z0-9_]+\.sql$", filename):
            errors.append(f"Migration '{filename}' does not follow naming convention: 001_name.sql")

        with open(sql_file, "r", encoding="utf-8") as f:
            sql_content = f.read().strip()

        if len(sql_content) < 50:
            errors.append(f"Migration '{filename}' is empty or trivial (< 50 chars). Dummy/stub migrations prohibited!")

    if errors:
        for err in errors:
            print(f"❌ {err}")
        return False

    print("✅ All present SQL migrations adhere to naming and content requirements.")
    return True


def check_backend_contract():
    print("\n=== [3] Verifying Backend Implementation Contract (Anti-Silent-Success) ===")
    backend_py_files = []
    for root, _, files in os.walk("backend"):
        if "tests" in root:
            continue
        for file in files:
            if file.endswith(".py"):
                backend_py_files.append(os.path.join(root, file))

    if not backend_py_files:
        print("ℹ️ No Python codebase found in backend/ (Status: FROZEN / MISSING).")
        return True

    print(f"Found {len(backend_py_files)} Python source file(s) in backend/.")
    errors = []

    # 1. requirements.txt must exist
    if not os.path.isfile("backend/requirements.txt"):
        errors.append("Backend Python files exist, but 'backend/requirements.txt' is missing!")

    # 2. backend/tests directory must exist and contain tests
    tests_dir = "backend/tests"
    if not os.path.isdir(tests_dir):
        errors.append("Backend implementation detected, but 'backend/tests/' directory is missing! Missing tests is strictly prohibited.")
    else:
        test_files = glob.glob(os.path.join(tests_dir, "test_*.py"))
        if not test_files:
            errors.append("Backend implementation detected, but no test_*.py files found in 'backend/tests/'! Dummy implementation without tests is prohibited.")

    if errors:
        for err in errors:
            print(f"❌ {err}")
        return False

    print("✅ Backend implementation contract satisfied (requirements and tests present).")
    return True


def check_workflow_contract():
    print("\n=== [4] Verifying n8n Workflows Contract ===")
    workflow_files = []
    for root, _, files in os.walk("workflows"):
        for file in files:
            if file.endswith(".json"):
                workflow_files.append(os.path.join(root, file))

    if not workflow_files:
        print("ℹ️ No workflow JSON files in workflows/ (Status: MISSING). Contract satisfied.")
        return True

    errors = []
    for wf in workflow_files:
        try:
            with open(wf, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict) or ("nodes" not in data and "name" not in data):
                errors.append(f"Workflow file '{wf}' is not a valid n8n workflow export.")
        except Exception as e:
            errors.append(f"Invalid JSON in '{wf}': {e}")

    if errors:
        for err in errors:
            print(f"❌ {err}")
        return False

    print(f"✅ All {len(workflow_files)} workflow files are valid JSON.")
    return True


def main():
    print("=" * 60)
    print("SHROT47 REPOSITORY INTEGRITY & ARCHITECTURE CONTRACT CHECK")
    print("=" * 60)

    success = True
    if not check_docs_schema_consistency():
        success = False
    if not check_migration_contract():
        success = False
    if not check_backend_contract():
        success = False
    if not check_workflow_contract():
        success = False

    print("\n" + "=" * 60)
    if not success:
        print("💥 ARCHITECTURE CONTRACT VIOLATION DETECTED! CI MUST FAIL.")
        print("=" * 60)
        sys.exit(1)
    else:
        print("🎉 ALL REPOSITORY CONTRACTS VERIFIED AND CONSISTENT.")
        print("=" * 60)
        sys.exit(0)


if __name__ == "__main__":
    main()
