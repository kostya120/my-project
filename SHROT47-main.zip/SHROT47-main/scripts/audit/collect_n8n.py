#!/usr/bin/env python3
"""
SHROT47 — n8n Read-Only Runtime Collector.

Collects:
- n8n version
- Workflow list (IDs, names, active/inactive status, tags)
- Webhook paths and HTTP methods
- Node types and versions
- Credential names and IDs ONLY (never credential values)

SAFETY:
- Uses ONLY HTTP GET requests.
- Never activates/deactivates workflows.
- Never extracts execution message payloads or credential values.
"""

import os
import json
import urllib.request
import urllib.error
from typing import Dict, Any
from .redactor import redact_data


def collect_n8n_inventory(base_url: str = None, api_key: str = None) -> Dict[str, Any]:
    base_url = (base_url or os.getenv("N8N_BASE_URL", "")).rstrip("/")
    api_key = api_key or os.getenv("N8N_AUDIT_API_KEY", "")

    result: Dict[str, Any] = {
        "collector": "n8n",
        "status": "UNCONFIGURED",
        "base_url": base_url or None,
        "version": None,
        "workflows_count": 0,
        "active_workflows_count": 0,
        "workflows": [],
        "webhook_endpoints": [],
        "credentials_inventory": [],
        "errors": []
    }

    if not base_url or not api_key:
        result["status"] = "MISSING_CREDENTIALS"
        result["errors"].append("N8N_BASE_URL or N8N_AUDIT_API_KEY is not configured.")
        return result

    headers = {
        "X-N8N-API-KEY": api_key,
        "Accept": "application/json",
        "User-Agent": "SHROT47-ReadOnly-Auditor/1.0"
    }

    # 1. Fetch Version
    try:
        req = urllib.request.Request(f"{base_url}/api/v1/version", headers=headers, method="GET")
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            result["version"] = data.get("version", data)
    except Exception as e:
        result["errors"].append(f"Failed to fetch n8n version: {str(e)}")

    # 2. Fetch Workflows
    try:
        req = urllib.request.Request(f"{base_url}/api/v1/workflows", headers=headers, method="GET")
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode())
            raw_workflows = data.get("data", data) if isinstance(data, dict) else data

            if isinstance(raw_workflows, list):
                result["workflows_count"] = len(raw_workflows)
                active_count = 0

                for wf in raw_workflows:
                    is_active = wf.get("active", False)
                    if is_active:
                        active_count += 1

                    # Extract node types and webhook paths without execution data
                    nodes_summary = []
                    for node in wf.get("nodes", []):
                        node_type = node.get("type", "unknown")
                        node_entry = {
                            "name": node.get("name"),
                            "type": node_type,
                            "typeVersion": node.get("typeVersion"),
                        }
                        nodes_summary.append(node_entry)

                        # If webhook node, record endpoint metadata
                        if "webhook" in node_type.lower():
                            params = node.get("parameters", {})
                            path = params.get("path", "")
                            http_method = params.get("httpMethod", "POST")
                            result["webhook_endpoints"].append({
                                "workflow_id": wf.get("id"),
                                "workflow_name": wf.get("name"),
                                "node_name": node.get("name"),
                                "path": path,
                                "http_method": http_method,
                                "is_active": is_active
                            })

                    wf_summary = {
                        "id": wf.get("id"),
                        "name": wf.get("name"),
                        "active": is_active,
                        "created_at": wf.get("createdAt"),
                        "updated_at": wf.get("updatedAt"),
                        "tags": [t.get("name") if isinstance(t, dict) else t for t in wf.get("tags", [])],
                        "nodes_count": len(nodes_summary),
                        "node_types": list(set(n["type"] for n in nodes_summary))
                    }
                    result["workflows"].append(wf_summary)

                result["active_workflows_count"] = active_count
                result["status"] = "SUCCESS"
    except urllib.error.HTTPError as e:
        result["status"] = f"HTTP_ERROR_{e.code}"
        result["errors"].append(f"HTTP Error {e.code}: {e.reason}")
    except Exception as e:
        result["status"] = "CONNECTION_FAILED"
        result["errors"].append(f"Connection failed: {str(e)}")

    # 3. Fetch Credentials Metadata (Names & IDs ONLY, NEVER data)
    try:
        req = urllib.request.Request(f"{base_url}/api/v1/credentials", headers=headers, method="GET")
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            creds = data.get("data", data) if isinstance(data, dict) else data
            if isinstance(creds, list):
                for c in creds:
                    result["credentials_inventory"].append({
                        "id": c.get("id"),
                        "name": c.get("name"),
                        "type": c.get("type"),
                        "created_at": c.get("createdAt")
                    })
    except Exception as e:
        # Credential list endpoint might be restricted in some n8n versions
        result["errors"].append(f"Credential metadata fetch note: {str(e)}")

    return redact_data(result)
