#!/usr/bin/env python3
"""
SHROT47 — SendPulse WhatsApp Read-Only Transport Collector.

Collects:
- WhatsApp bot / channel connection status and metadata
- Webhook configuration metadata (target URL, subscribed events)
- Active automation scenario names and trigger statuses

SAFETY:
- NEVER sends outbound messages (NO POST to /whatsapp/messages).
- NEVER exports contact lists or customer phone numbers.
- NEVER modifies or creates webhook triggers.
"""

import os
import json
import urllib.request
import urllib.parse
import urllib.error
from typing import Dict, Any
from .redactor import redact_data


def collect_sendpulse_inventory(
    client_id: str = None,
    client_secret: str = None,
    audit_token: str = None
) -> Dict[str, Any]:
    client_id = client_id or os.getenv("SENDPULSE_CLIENT_ID", "")
    client_secret = client_secret or os.getenv("SENDPULSE_CLIENT_SECRET", "")
    audit_token = audit_token or os.getenv("SENDPULSE_AUDIT_TOKEN", "")

    result: Dict[str, Any] = {
        "collector": "sendpulse",
        "status": "UNCONFIGURED",
        "bots": [],
        "webhooks_configured": [],
        "scenarios": [],
        "errors": []
    }

    if not audit_token and (not client_id or not client_secret):
        result["status"] = "MISSING_CREDENTIALS"
        result["errors"].append("SendPulse credentials (CLIENT_ID/SECRET or AUDIT_TOKEN) are not configured.")
        return result

    # 1. Obtain Bearer Token if not provided directly
    token = audit_token
    if not token and client_id and client_secret:
        try:
            auth_url = "https://api.sendpulse.com/oauth/access_token"
            auth_payload = json.dumps({
                "grant_type": "client_credentials",
                "client_id": client_id,
                "client_secret": client_secret
            }).encode("utf-8")

            req = urllib.request.Request(
                auth_url,
                data=auth_payload,
                headers={"Content-Type": "application/json"},
                method="POST"
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                auth_data = json.loads(resp.read().decode())
                token = auth_data.get("access_token")
        except urllib.error.HTTPError as e:
            result["status"] = f"AUTH_ERROR_{e.code}"
            result["errors"].append(f"SendPulse auth failed with code {e.code}: {e.reason}")
            return redact_data(result)
        except Exception as e:
            result["status"] = "AUTH_FAILED"
            result["errors"].append(f"SendPulse authentication exception: {str(e)}")
            return redact_data(result)

    if not token:
        result["status"] = "TOKEN_UNAVAILABLE"
        result["errors"].append("Failed to obtain SendPulse bearer token.")
        return redact_data(result)

    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "User-Agent": "SHROT47-ReadOnly-Auditor/1.0"
    }

    # 2. Query WhatsApp Bots / Channels
    bot_ids = []
    try:
        req = urllib.request.Request("https://api.sendpulse.com/whatsapp/bots", headers=headers, method="GET")
        with urllib.request.urlopen(req, timeout=10) as resp:
            bots_data = json.loads(resp.read().decode())
            bots_list = bots_data if isinstance(bots_data, list) else bots_data.get("data", [])
            for b in bots_list:
                bid = b.get("id")
                bot_ids.append(bid)
                result["bots"].append({
                    "id": bid,
                    "name": b.get("name"),
                    "channel": b.get("channel"),
                    "status": b.get("status"),
                    "created_at": b.get("created_at")
                })
        result["status"] = "SUCCESS"
    except Exception as e:
        result["errors"].append(f"Failed to query SendPulse WhatsApp bots: {str(e)}")

    # 3. Query Webhook Configuration for discovered bots
    for bid in bot_ids:
        try:
            req = urllib.request.Request(f"https://api.sendpulse.com/whatsapp/bots/{bid}/webhooks", headers=headers, method="GET")
            with urllib.request.urlopen(req, timeout=10) as resp:
                wh_data = json.loads(resp.read().decode())
                wh_list = wh_data if isinstance(wh_data, list) else wh_data.get("data", [])
                for wh in wh_list:
                    result["webhooks_configured"].append({
                        "bot_id": bid,
                        "url": wh.get("url"),
                        "events": wh.get("events"),
                        "status": wh.get("status")
                    })
        except Exception as e:
            result["errors"].append(f"Failed to query webhooks for bot {bid}: {str(e)}")

        # 4. Query Scenario Triggers (Metadata ONLY, no message logs)
        try:
            req = urllib.request.Request(f"https://api.sendpulse.com/whatsapp/bots/{bid}/triggers", headers=headers, method="GET")
            with urllib.request.urlopen(req, timeout=10) as resp:
                trig_data = json.loads(resp.read().decode())
                trig_list = trig_data if isinstance(trig_data, list) else trig_data.get("data", [])
                for tr in trig_list:
                    result["scenarios"].append({
                        "bot_id": bid,
                        "trigger_id": tr.get("id"),
                        "name": tr.get("name"),
                        "type": tr.get("type"),
                        "status": tr.get("status")
                    })
        except Exception as e:
            result["errors"].append(f"Failed to query triggers for bot {bid}: {str(e)}")

    return redact_data(result)
