#!/usr/bin/env python3
"""
SHROT47 — Mandatory Redaction Engine for Runtime Audit Tools.

Guarantees:
- Passwords, tokens, API keys, private keys, cookies, auth headers are replaced with [REDACTED].
- Environment values are masked; only variable names are retained.
- PII (phone numbers, customer emails) is sanitized.
- Safe for recursive traversal of arbitrary JSON/dict/list structures.
"""

import re
from typing import Any

# Sensitive key names (case-insensitive) whose values must be masked
SENSITIVE_KEY_PATTERNS = [
    r"pass(word)?",
    r"secret",
    r"token",
    r"api[_-]?key",
    r"auth",
    r"bearer",
    r"private[_-]?key",
    r"credential(s)?",
    r"service[_-]?role",
    r"cookie",
    r"session",
    r"signature",
    r"webhook[_-]?secret",
    r"encryption[_-]?key",
]

# Sensitive value regex patterns that must be redacted even if key name is innocent
SENSITIVE_VALUE_REGEXES = [
    (re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----[\s\S]+?-----END (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"), "[REDACTED_PRIVATE_KEY]"),
    (re.compile(r"eyJ[a-zA-Z0-9_\-]{10,}\.eyJ[a-zA-Z0-9_\-]{10,}\.[a-zA-Z0-9_\-]{10,}"), "[REDACTED_JWT]"),
    (re.compile(r"ghp_[a-zA-Z0-9]{36}"), "[REDACTED_GITHUB_TOKEN]"),
    (re.compile(r"AIza[0-9A-Za-z-_]{35}"), "[REDACTED_GOOGLE_API_KEY]"),
    (re.compile(r"sk-[a-zA-Z0-9]{20,}"), "[REDACTED_OPENAI_KEY]"),
    (re.compile(r"postgres(?:ql)?:\/\/[^:]+:([^@]+)@"), "postgresql://[USER]:[REDACTED_PASSWORD]@"),
]

PHONE_REGEX = re.compile(r"(?:\+?7|8)[\s\-]?\(?(\d{3})\)?[\s\-]?(\d{3})[\s\-]?(\d{2})[\s\-]?(\d{2})")


def is_sensitive_key(key: str) -> bool:
    if not isinstance(key, str):
        return False
    lower_key = key.lower()
    for pattern in SENSITIVE_KEY_PATTERNS:
        if re.search(pattern, lower_key):
            return True
    return False


def redact_string(val: str) -> str:
    if not isinstance(val, str):
        return val

    # Check for direct value patterns
    for regex, replacement in SENSITIVE_VALUE_REGEXES:
        val = regex.sub(replacement, val)

    # Sanitize phone numbers to preserve only region code and last 2 digits
    def mask_phone(match):
        prefix = match.group(1)
        suffix = match.group(4)
        return f"+7 ({prefix}) ***-**-{suffix}"

    val = PHONE_REGEX.sub(mask_phone, val)
    return val


def redact_data(data: Any, parent_key: str = "") -> Any:
    """Recursively redacts sensitive keys and values from dictionary/list/primitive."""
    if data is None:
        return None

    # If the parent key itself is sensitive, mask the entire value immediately
    if is_sensitive_key(parent_key):
        if isinstance(data, (str, int, float, bool)):
            return "[REDACTED]"
        if isinstance(data, (dict, list)):
            return "[REDACTED_STRUCTURE]"

    if isinstance(data, dict):
        sanitized = {}
        for k, v in data.items():
            if is_sensitive_key(str(k)):
                if isinstance(v, (dict, list)):
                    sanitized[k] = "[REDACTED_STRUCTURE]"
                else:
                    sanitized[k] = "[REDACTED]"
            else:
                sanitized[k] = redact_data(v, parent_key=str(k))
        return sanitized

    if isinstance(data, list):
        return [redact_data(item, parent_key=parent_key) for item in data]

    if isinstance(data, str):
        return redact_string(data)

    return data


def redact_env_pairs(env_list_or_dict: Any) -> dict:
    """Accepts list of 'KEY=VALUE' or dict of env vars and returns dict with only keys and [REDACTED] values."""
    sanitized = {}
    if isinstance(env_list_or_dict, list):
        for item in env_list_or_dict:
            if isinstance(item, str) and "=" in item:
                k, _ = item.split("=", 1)
                sanitized[k] = "[REDACTED]"
    elif isinstance(env_list_or_dict, dict):
        for k in env_list_or_dict.keys():
            sanitized[k] = "[REDACTED]"
    return sanitized
