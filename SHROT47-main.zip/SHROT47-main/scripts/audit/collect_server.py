#!/usr/bin/env python3
"""
SHROT47 — Server & Container Read-Only Runtime Collector.

Collects:
- Running Docker containers (names, images, status, port bindings)
- Docker Compose project names
- Listening TCP/UDP network ports
- Reverse proxy route configurations (Nginx/Traefik sites if readable)
- Environment variable NAMES only (strictly masks all values)
- Storage & memory utilization summary

SAFETY:
- Uses ONLY non-destructive inspection commands (`docker ps`, `docker inspect`, `ss -tulpn`, `df -h`).
- NEVER executes restart, stop, rm, or config modification commands.
- Masking guarantees zero value exposure.
"""

import os
import json
import subprocess
from typing import Dict, Any
from .redactor import redact_data, redact_env_pairs


def collect_server_inventory(host: str = None) -> Dict[str, Any]:
    result: Dict[str, Any] = {
        "collector": "server",
        "status": "INSPECTING_LOCAL",
        "host": host or "localhost",
        "docker_available": False,
        "containers": [],
        "compose_projects": [],
        "listening_ports": [],
        "reverse_proxy_routes": [],
        "environment_variable_names": [],
        "system_summary": {},
        "errors": []
    }

    # 1. Inspect Docker Containers (Safe read-only)
    try:
        cmd = ["docker", "ps", "--all", "--format", "{{json .}}"]
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10)
        if proc.returncode == 0:
            result["docker_available"] = True
            lines = proc.stdout.strip().splitlines()
            for line in lines:
                if line.strip():
                    try:
                        c_data = json.loads(line)
                        container_name = c_data.get("Names")
                        image = c_data.get("Image")
                        status = c_data.get("Status")
                        ports = c_data.get("Ports")

                        entry = {
                            "name": container_name,
                            "image": image,
                            "status": status,
                            "state": c_data.get("State"),
                            "ports": ports,
                            "created": c_data.get("CreatedAt")
                        }
                        result["containers"].append(entry)

                        # Check compose project label
                        labels = c_data.get("Labels", "")
                        if "com.docker.compose.project=" in labels:
                            proj = labels.split("com.docker.compose.project=")[1].split(",")[0]
                            if proj not in result["compose_projects"]:
                                result["compose_projects"].append(proj)
                    except Exception:
                        pass
        else:
            result["errors"].append(f"docker ps returned code {proc.returncode}: {proc.stderr.strip()}")
    except FileNotFoundError:
        result["errors"].append("Docker binary not installed or not in PATH.")
    except Exception as e:
        result["errors"].append(f"Docker inspection failed: {str(e)}")

    # 2. Inspect Environment Variable Names (ONLY variable names, NEVER values)
    # Check .env files in directory if present
    for env_candidate in [".env", ".env.local", ".env.production"]:
        if os.path.isfile(env_candidate):
            try:
                with open(env_candidate, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#") and "=" in line:
                            var_name = line.split("=", 1)[0].strip()
                            if var_name not in result["environment_variable_names"]:
                                result["environment_variable_names"].append(var_name)
            except Exception:
                pass

    # 3. Inspect Listening Ports (Safe read-only ss / netstat)
    try:
        proc = subprocess.run(["ss", "-tulpn"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=5)
        if proc.returncode == 0:
            for line in proc.stdout.splitlines()[1:]:
                parts = line.split()
                if len(parts) >= 5:
                    proto = parts[0]
                    local_addr = parts[4]
                    proc_info = parts[6] if len(parts) > 6 else ""
                    result["listening_ports"].append({
                        "protocol": proto,
                        "local_address": local_addr,
                        "process": proc_info
                    })
    except Exception:
        # Fallback or skip if ss is restricted
        pass

    # 4. Check Common Nginx / Reverse Proxy Configs (Read-only paths)
    nginx_paths = ["/etc/nginx/sites-enabled", "/etc/nginx/conf.d"]
    for np in nginx_paths:
        if os.path.isdir(np):
            try:
                for root, _, files in os.walk(np):
                    for file in files:
                        cpath = os.path.join(root, file)
                        try:
                            with open(cpath, "r", encoding="utf-8", errors="ignore") as f:
                                for line in f:
                                    line = line.strip()
                                    if line.startswith("location") or line.startswith("server_name") or line.startswith("proxy_pass"):
                                        result["reverse_proxy_routes"].append({
                                            "file": file,
                                            "directive": line
                                        })
                        except Exception:
                            pass
            except Exception:
                pass

    # 5. System summary (Disk and uptime)
    try:
        df_proc = subprocess.run(["df", "-h", "/"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=5)
        if df_proc.returncode == 0 and len(df_proc.stdout.splitlines()) > 1:
            result["system_summary"]["disk_root"] = df_proc.stdout.splitlines()[1]
    except Exception:
        pass

    result["status"] = "SUCCESS" if result["docker_available"] or result["listening_ports"] else "PARTIAL_INSPECTION"
    return redact_data(result)
