#!/usr/bin/env python3
"""
SHROT47 — Runtime Routes & Network Flow Synthesizer.

Aggregates:
- SendPulse webhook targets
- n8n active webhook endpoints
- Reverse proxy (Nginx) locations and proxies
- Backend OpenAPI routes (if running)

Validates:
- Does SendPulse point directly to n8n (canonical)?
- Are there any duplicate or conflicting webhook listeners?
"""

import os
from typing import Dict, Any, List
from .redactor import redact_data


def synthesize_runtime_routes(
    n8n_data: Dict[str, Any],
    server_data: Dict[str, Any],
    sendpulse_data: Dict[str, Any]
) -> Dict[str, Any]:
    routes: Dict[str, Any] = {
        "collector": "runtime_routes",
        "inbound_pipeline": {
            "sendpulse_webhooks": [],
            "n8n_webhook_endpoints": [],
            "reverse_proxy_routes": []
        },
        "topology_checks": {
            "sendpulse_points_to_n8n": "UNKNOWN",
            "duplicate_webhook_receivers_detected": False,
            "notes": []
        }
    }

    # Extract SendPulse Webhooks
    sp_urls = []
    for wh in sendpulse_data.get("webhooks_configured", []):
        url = wh.get("url", "")
        sp_urls.append(url)
        routes["inbound_pipeline"]["sendpulse_webhooks"].append({
            "url": url,
            "events": wh.get("events"),
            "status": wh.get("status")
        })

    # Extract n8n Webhook Endpoints
    n8n_paths = []
    for ep in n8n_data.get("webhook_endpoints", []):
        path = ep.get("path", "")
        n8n_paths.append(path)
        routes["inbound_pipeline"]["n8n_webhook_endpoints"].append(ep)

    # Extract Reverse Proxy Directives
    for rp in server_data.get("reverse_proxy_routes", []):
        routes["inbound_pipeline"]["reverse_proxy_routes"].append(rp)

    # Topology Evaluation
    if sp_urls:
        matches = [u for u in sp_urls if any(p in u for p in n8n_paths if p)]
        if matches:
            routes["topology_checks"]["sendpulse_points_to_n8n"] = "CONFIRMED"
            routes["topology_checks"]["notes"].append("SendPulse webhook target matches registered n8n webhook path.")
        else:
            routes["topology_checks"]["sendpulse_points_to_n8n"] = "UNVERIFIED"
            routes["topology_checks"]["notes"].append("SendPulse webhook URLs do not explicitly match n8n local paths (may use custom domain or reverse proxy).")

    return redact_data(routes)
