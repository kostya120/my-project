#!/usr/bin/env python3
"""
SHROT47 — Master Read-Only Runtime Audit Orchestrator.

Usage:
    python3 scripts/audit/run_audit.py [--output-dir audit-output]

Outputs bundle:
    audit-output/n8n_inventory.json
    audit-output/supabase_schema.json
    audit-output/server_inventory.json
    audit-output/sendpulse_inventory.json
    audit-output/runtime_routes.json
    audit-output/AUDIT_SUMMARY.md

SAFETY:
- Strictly READ-ONLY.
- All secrets, tokens, passwords, and PII are redacted.
- Production is not modified.
"""

import os
import sys
import json
import argparse
from datetime import datetime, timezone
from pathlib import Path

# Add current scripts directory to import path
script_dir = Path(__file__).resolve().parent
sys.path.insert(0, str(script_dir.parent.parent))

from scripts.audit.redactor import redact_data
from scripts.audit.collect_n8n import collect_n8n_inventory
from scripts.audit.collect_supabase import collect_supabase_schema
from scripts.audit.collect_server import collect_server_inventory
from scripts.audit.collect_sendpulse import collect_sendpulse_inventory
from scripts.audit.collect_routes import synthesize_runtime_routes


def load_env_audit_file(filepath: str = ".env.audit"):
    """Loads key=value pairs into os.environ if .env.audit exists."""
    if os.path.isfile(filepath):
        print(f"📖 Loading audit environment from {filepath}...")
        with open(filepath, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    k = k.strip()
                    v = v.strip().strip("'\"")
                    if k and k not in os.environ:
                        os.environ[k] = v


def generate_audit_summary_markdown(
    n8n_data: dict,
    supabase_data: dict,
    server_data: dict,
    sendpulse_data: dict,
    routes_data: dict,
    output_path: str
):
    timestamp = datetime.now(timezone.utc).isoformat()
    lines = [
        "# SHROT47 — Runtime Audit Summary Report",
        "",
        f"**Дата аудита (UTC):** `{timestamp}`  ",
        "**Режим:** `READ-ONLY INSPECTION`  ",
        "**Production статус:** `PRODUCTION OFF` (Никакие боевые сервисы не модифицировались)  ",
        "",
        "---",
        "",
        "## 1. Сводный статус инспектирования систем",
        "",
        "| Компонент / Система | Статус коллектора | Обнаруженные артефакты / Замечания |",
        "| :--- | :--- | :--- |",
        f"| **n8n Workflow Engine** | `{n8n_data.get('status')}` | Воркфлоу: `{n8n_data.get('workflows_count')}` (активных: `{n8n_data.get('active_workflows_count')}`), эндпоинтов: `{len(n8n_data.get('webhook_endpoints', []))}` |",
        f"| **Supabase (PostgreSQL)** | `{supabase_data.get('status')}` | Таблиц обнаружено: `{len(supabase_data.get('tables', {}))}`, RLS политик: `{len(supabase_data.get('rls_policies', []))}` |",
        f"| **Server / Docker Host** | `{server_data.get('status')}` | Docker доступен: `{server_data.get('docker_available')}`, контейнеров: `{len(server_data.get('containers', []))}` |",
        f"| **SendPulse (WhatsApp)** | `{sendpulse_data.get('status')}` | Ботов: `{len(sendpulse_data.get('bots', []))}`, вебхуков: `{len(sendpulse_data.get('webhooks_configured', []))}` |",
        "",
        "---",
        "",
        "## 2. Верификация канонической схемы Supabase (8 таблиц)",
        "",
        "| Каноническая таблица | Статус в реальной БД | Примечание |",
        "| :--- | :--- | :--- |",
    ]

    canonical_presence = supabase_data.get("canonical_tables_present", {})
    for tbl, present in canonical_presence.items():
        status_icon = "✅ Присутствует" if present else "❌ Не обнаружена (MISSING)"
        lines.append(f"| `{tbl}` | {status_icon} | Каноническая доменная модель |")

    lines.extend([
        "",
        "---",
        "",
        "## 3. Топология сетевых маршрутов (Routes)",
        "",
        f"- **Связка SendPulse → n8n:** `{routes_data.get('topology_checks', {}).get('sendpulse_points_to_n8n')}`",
        f"- **Дублирование вебхуков:** `{'ОБНАРУЖЕНО' if routes_data.get('topology_checks', {}).get('duplicate_webhook_receivers_detected') else 'НЕТ (Соответствует норме)'}`",
        "",
        "---",
        "",
        "## 4. Гарантии безопасности и санитизации данных",
        "",
        "- Все пароли, сервисные ключи, токены и секреты **принудительно маскированы** (`[REDACTED]`).",
        "- Персональные данные клиентов и телефонные номера **не экспортировались**.",
        "- Никаких мутаций данных (`INSERT/UPDATE/DELETE/ALTER`) не производилось.",
        "- Выходной каталог `audit-output/` защищен правилами `.gitignore`.",
        "",
        "---",
        "*Отчет сформирован автономным аудитором SHROT47.*"
    ])

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


def main():
    parser = argparse.ArgumentParser(description="SHROT47 Runtime Read-Only Auditor")
    parser.add_argument("--output-dir", default="audit-output", help="Directory to save audit bundle")
    parser.add_argument("--env-file", default=".env.audit", help="Path to audit env configuration file")
    args = parser.parse_args()

    print("=" * 65)
    print("🚀 SHROT47 RUNTIME READ-ONLY AUDIT COLLECTOR")
    print("=" * 65)

    load_env_audit_file(args.env_file)

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 1. Collect n8n
    print("📦 [1/5] Collecting n8n inventory...")
    n8n_data = collect_n8n_inventory()
    with open(output_dir / "n8n_inventory.json", "w", encoding="utf-8") as f:
        json.dump(n8n_data, f, indent=2, ensure_ascii=False)

    # 2. Collect Supabase
    print("📦 [2/5] Collecting Supabase / PostgreSQL schema...")
    supabase_data = collect_supabase_schema()
    with open(output_dir / "supabase_schema.json", "w", encoding="utf-8") as f:
        json.dump(supabase_data, f, indent=2, ensure_ascii=False)

    # 3. Collect Server
    print("📦 [3/5] Collecting server and Docker inventory...")
    server_data = collect_server_inventory()
    with open(output_dir / "server_inventory.json", "w", encoding="utf-8") as f:
        json.dump(server_data, f, indent=2, ensure_ascii=False)

    # 4. Collect SendPulse
    print("📦 [4/5] Collecting SendPulse WhatsApp transport metadata...")
    sendpulse_data = collect_sendpulse_inventory()
    with open(output_dir / "sendpulse_inventory.json", "w", encoding="utf-8") as f:
        json.dump(sendpulse_data, f, indent=2, ensure_ascii=False)

    # 5. Synthesize Routes
    print("📦 [5/5] Synthesizing runtime routes and network flow...")
    routes_data = synthesize_runtime_routes(n8n_data, server_data, sendpulse_data)
    with open(output_dir / "runtime_routes.json", "w", encoding="utf-8") as f:
        json.dump(routes_data, f, indent=2, ensure_ascii=False)

    # Generate Summary Markdown
    print("📝 Generating AUDIT_SUMMARY.md...")
    generate_audit_summary_markdown(
        n8n_data, supabase_data, server_data, sendpulse_data, routes_data,
        str(output_dir / "AUDIT_SUMMARY.md")
    )

    print("=" * 65)
    print(f"🎉 Audit bundle generated successfully in: {output_dir.resolve()}")
    print("   - n8n_inventory.json")
    print("   - supabase_schema.json")
    print("   - server_inventory.json")
    print("   - sendpulse_inventory.json")
    print("   - runtime_routes.json")
    print("   - AUDIT_SUMMARY.md")
    print("=" * 65)


if __name__ == "__main__":
    main()
