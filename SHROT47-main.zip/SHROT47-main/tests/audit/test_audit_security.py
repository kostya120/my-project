#!/usr/bin/env python3
"""
SHROT47 — Security & Safety Test Suite for Runtime Audit Tools.

Tests:
1. Redaction Engine: masks passwords, tokens, JWTs, keys, and customer phone numbers.
2. Read-Only Enforcement: checks that collectors never issue write/mutation operations.
3. Fail-Safe Behavior: collectors fail safely when credentials are missing or services unreachable.
4. Git Safety: verifies .env.audit and audit-output/ are ignored, while .env.audit.example is tracked.
5. End-to-End Orchestrator: run_audit produces the bundle safely with zero secret leakage.
"""

import os
import sys
import json
import unittest
import subprocess
from pathlib import Path

# Add repo root to path
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(REPO_ROOT))

from scripts.audit.redactor import redact_data, redact_string, is_sensitive_key, redact_env_pairs
from scripts.audit.collect_n8n import collect_n8n_inventory
from scripts.audit.collect_supabase import collect_supabase_schema
from scripts.audit.collect_server import collect_server_inventory
from scripts.audit.collect_sendpulse import collect_sendpulse_inventory


class TestAuditSecurity(unittest.TestCase):

    def test_redaction_engine_sensitive_keys(self):
        """Verify that dictionary keys associated with secrets are masked."""
        raw_payload = {
            "name": "Production Bot",
            "api_key": "secret_api_key_12345",
            "password": "SuperSecretPassword!",
            "token": "bearer_token_xyz",
            "service_role_key": "supabase_service_role_key_value",
            "credentials": {
                "user": "admin",
                "password": "db_password_abc"
            },
            "innocent_field": "public_data"
        }
        redacted = redact_data(raw_payload)

        self.assertEqual(redacted["api_key"], "[REDACTED]")
        self.assertEqual(redacted["password"], "[REDACTED]")
        self.assertEqual(redacted["token"], "[REDACTED]")
        self.assertEqual(redacted["service_role_key"], "[REDACTED]")
        self.assertEqual(redacted["credentials"], "[REDACTED_STRUCTURE]")
        self.assertEqual(redacted["innocent_field"], "public_data")

    def test_redaction_engine_value_patterns(self):
        """Verify that high-entropy tokens and private keys are masked even in unflagged fields."""
        jwt_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIn0.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
        raw_text = f"Connection string postgresql://postgres:MySecretPass123@db.supabase.co:5432/postgres and token {jwt_token}"

        redacted = redact_string(raw_text)
        self.assertNotIn("MySecretPass123", redacted)
        self.assertIn("postgresql://[USER]:[REDACTED_PASSWORD]@", redacted)
        self.assertNotIn(jwt_token, redacted)
        self.assertIn("[REDACTED_JWT]", redacted)

    def test_phone_number_masking(self):
        """Verify that customer phone numbers (PII) are masked."""
        raw_phone = "Customer called from +7 701 123 45 67 about part"
        redacted = redact_string(raw_phone)
        self.assertNotIn("123 45", redacted)
        self.assertIn("+7 (701) ***-**-67", redacted)

    def test_env_pairs_redaction(self):
        """Verify that environment variable values are stripped while preserving names."""
        env_sample = [
            "SUPABASE_URL=https://xyz.supabase.co",
            "SUPABASE_SERVICE_ROLE_KEY=secret_key_123",
            "DATABASE_PASSWORD=super_secret"
        ]
        redacted = redact_env_pairs(env_sample)
        self.assertIn("SUPABASE_URL", redacted)
        self.assertIn("SUPABASE_SERVICE_ROLE_KEY", redacted)
        self.assertEqual(redacted["SUPABASE_SERVICE_ROLE_KEY"], "[REDACTED]")
        self.assertEqual(redacted["DATABASE_PASSWORD"], "[REDACTED]")

    def test_fail_safe_missing_credentials(self):
        """Collectors must fail gracefully with MISSING_CREDENTIALS when run unconfigured."""
        n8n_res = collect_n8n_inventory(base_url="", api_key="")
        self.assertEqual(n8n_res["status"], "MISSING_CREDENTIALS")
        self.assertTrue(len(n8n_res["errors"]) > 0)

        sb_res = collect_supabase_schema(supabase_url="", audit_key="", db_url="")
        self.assertEqual(sb_res["status"], "MISSING_CREDENTIALS")
        self.assertTrue(len(sb_res["errors"]) > 0)

        sp_res = collect_sendpulse_inventory(client_id="", client_secret="", audit_token="")
        self.assertEqual(sp_res["status"], "MISSING_CREDENTIALS")
        self.assertTrue(len(sp_res["errors"]) > 0)

    def test_read_only_guarantee_in_collectors(self):
        """Inspect collector code to ensure forbidden write commands/methods are absent."""
        # 1. Supabase collector should not have mutating SQL statements
        sb_file = REPO_ROOT / "scripts" / "audit" / "collect_supabase.py"
        with open(sb_file, "r", encoding="utf-8") as f:
            content = f.read()
        mutating_sql = ["INSERT INTO", "UPDATE ", "DELETE FROM", "DROP TABLE", "ALTER TABLE", "TRUNCATE"]
        for stmt in mutating_sql:
            self.assertNotIn(stmt, content, f"Forbidden mutating SQL '{stmt}' found in collect_supabase.py")

        # 2. Server collector should not execute mutating docker commands
        server_file = REPO_ROOT / "scripts" / "audit" / "collect_server.py"
        with open(server_file, "r", encoding="utf-8") as f:
            content = f.read()
        mutating_docker = ["docker stop", "docker restart", "docker rm", "docker kill"]
        for cmd in mutating_docker:
            self.assertNotIn(cmd, content, f"Forbidden mutating command '{cmd}' found in collect_server.py")

    def test_gitignore_ignores_audit_secrets(self):
        """Verify that Git correctly ignores .env.audit and audit-output/."""
        # Test .env.audit ignore check
        check_proc = subprocess.run(
            ["git", "check-ignore", ".env.audit"],
            cwd=str(REPO_ROOT),
            stdout=subprocess.PIPE,
            text=True
        )
        self.assertEqual(check_proc.returncode, 0, ".env.audit must be ignored by Git!")

        # Test audit-output directory ignore check
        check_proc_out = subprocess.run(
            ["git", "check-ignore", "audit-output/n8n_inventory.json"],
            cwd=str(REPO_ROOT),
            stdout=subprocess.PIPE,
            text=True
        )
        self.assertEqual(check_proc_out.returncode, 0, "audit-output/ files must be ignored by Git!")

        # Test .env.audit.example is NOT ignored
        check_example = subprocess.run(
            ["git", "check-ignore", ".env.audit.example"],
            cwd=str(REPO_ROOT),
            stdout=subprocess.PIPE,
            text=True
        )
        self.assertNotEqual(check_example.returncode, 0, ".env.audit.example must NOT be ignored by Git!")

    def test_run_audit_end_to_end_safety(self):
        """Run run_audit.py and ensure the output bundle is created and completely safe."""
        output_dir = REPO_ROOT / "audit-output-test"
        cmd = [sys.executable, str(REPO_ROOT / "scripts" / "audit" / "run_audit.py"), "--output-dir", str(output_dir)]
        proc = subprocess.run(cmd, cwd=str(REPO_ROOT), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        self.assertEqual(proc.returncode, 0, f"run_audit.py failed: {proc.stderr}")

        expected_files = [
            "n8n_inventory.json",
            "supabase_schema.json",
            "server_inventory.json",
            "sendpulse_inventory.json",
            "runtime_routes.json",
            "AUDIT_SUMMARY.md"
        ]
        for fname in expected_files:
            target = output_dir / fname
            self.assertTrue(target.is_file(), f"Missing expected output file: {fname}")

            # Verify no secrets or sensitive signatures inside
            with open(target, "r", encoding="utf-8") as f:
                c = f.read()
            self.assertNotIn("BEGIN RSA PRIVATE KEY", c)
            self.assertNotIn("BEGIN OPENSSH PRIVATE KEY", c)

        # Cleanup test output directory
        import shutil
        shutil.rmtree(output_dir)


if __name__ == "__main__":
    unittest.main()
