# Руководство по участию в проекте SHROT47

Спасибо, что хотите внести свой вклад в SHROT47.

## Основные правила

- Все изменения вносятся только через Pull Request
- Ветка `main` защищена и не должна обновляться напрямую
- Разработка ведётся в ветке `develop` или в `feature/*`
- Перед созданием PR обязательно запускайте локальные проверки

## Стратегия веток

- `main` — продакшн версия
- `develop` — интеграционная ветка для тестирования и сборки
- `feature/*` — новые функции и изменения
- `fix/*` — исправления багов
- `hotfix/*` — срочные исправления для продакшна

## Начало работы

1. Клонируйте репозиторий:
   ```bash
   git clone https://github.com/kostya120/SHROT47.git
   cd SHROT47
   ```

2. Создайте ветку от `develop`:
   ```bash
   git checkout develop
   git pull origin develop
   git checkout -b feature/your-feature-name
   ```

3. Внесите изменения и сделайте коммит:
   ```bash
   git add .
   git commit -m "Add feature description"
   ```

4. Загрузите ветку на GitHub:
   ```bash
   git push origin feature/your-feature-name
   ```

5. Откройте Pull Request в ветку `develop`

## Проверки перед PR

Перед созданием PR убедитесь, что:

```bash
# Если есть python-проект
python -m pip install -r backend/requirements.txt
pylint backend/app
mypy backend/app
pytest backend/tests
```

Если проект использует Docker:

```bash
docker-compose build
```

## Code review

- PR должен иметь понятное описание изменений
- В PR желательно указать проблему/задачу, которую закрывает изменение
- Комментарии к коду должны быть конструктивными
- Не объединяйте несвязанные изменения в один PR

## Коммиты

Используйте понятные и короткие сообщения:

```bash
git commit -m "Add libphonenumber normalization for customer lookup"
```

## Pull Request checklist

Перед merge убедитесь, что:

- [ ] Код проходит lint
- [ ] Тесты проходят
- [ ] Нет конфликтов с `develop`
- [ ] Обновлена документация, если это необходимо
- [ ] PR имеет понятное описание

## Контакты

Для вопросов используйте GitHub Issues или обсуждения внутри команды.
