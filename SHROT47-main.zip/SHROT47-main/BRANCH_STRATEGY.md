# Стратегия ветвления SHROT47

## Цель

Упростить параллельную работу нескольких разработчиков, уменьшить число конфликтов и обеспечить безопасный выпуск изменений.

## Основные ветки

- `main` — стабильная продакшн-ветка
- `develop` — рабочая ветка для интеграции и тестирования
- `feature/*` — новые фичи
- `fix/*` — исправления ошибок
- `hotfix/*` — срочные исправления продакшн-проекта

## Правила работы

### 1. Разработка в feature ветках

Каждый разработчик работает в своей ветке:

```bash
git checkout develop
git pull origin develop
git checkout -b feature/llm-safety-layer
```

Нельзя вносить изменения напрямую в `main` или `develop`.

### 2. PR в develop

Когда задача готова:

- создайте Pull Request в `develop`
- заполните описание: что сделано, зачем, как проверить
- назначьте ревьюверов
- дождитесь одобрения

### 3. Проверка качества

Для каждого PR должен выполниться CI pipeline:

- lint
- static checks
- unit tests
- docker build

Если проверка не пройдена, PR нельзя мержить.

### 4. Merge strategy

Рекомендуется использовать:

- `Squash and merge` для небольших feature веток
- `Merge commit` для сложных изменений и связанных задач
- `Rebase` при необходимости для локальной синхронизации ветки

### 5. Синхронизация с develop

Перед созданием PR надо обновить ветку:

```bash
git fetch origin
git rebase origin/develop
```

Если есть конфликты, их нужно решить локально перед PR.

### 6. Защита веток

Для `main` и `develop` следует включить:

- Require pull request reviews before merging
- Require status checks to pass before merging
- Require branches to be up to date before merging
- Do not allow direct pushes

## Типовой рабочий процесс команды

```text
Developer A -> feature/price-agent
Developer B -> feature/llm-safety
Developer C -> feature/appsmith-dashboard

feature/* -> PR -> develop -> QA -> main
```

## Пример ежедневного цикла

1. Обновить `develop`
2. Создать feature ветку
3. Разработать задачу
4. Прогнать локальные тесты
5. Сделать push
6. Открыть PR
7. Получить review
8. Merge в `develop`
9. После стабилизации — merge в `main`

## Рекомендации

- Один PR = одна цель
- Не смешивайте технический долг и новые фичи в одном PR
- Пишите понятные названия веток и коммитов
- Комментируйте значимые решения и архитектурные изменения

## Итог

Эта стратегия позволяет:

- работать параллельно нескольким разработчикам
- уменьшать число конфликтов
- держать `main` стабильной
- быстро находить и исправлять ошибки
